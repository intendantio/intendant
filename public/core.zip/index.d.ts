
import core from './core'

declare module "@intendant/core" {

   

    export default core;

}  

