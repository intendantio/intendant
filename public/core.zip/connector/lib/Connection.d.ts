export class Connection {
    public static getInstance(configuration: Object): Object;
}



