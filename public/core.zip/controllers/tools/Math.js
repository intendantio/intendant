"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.default=void 0;class Utils{static random(a){for(var b="",c=function(){var a=String.fromCharCode,b=Math.floor,c=b(62*Math.random());return 10>c?c:36>c?a(c+55):a(c+61);//1-10
//A-Z
//a-z
};b.length<a;)b+=c();return b}}var _default=Utils;exports.default=_default,module.exports=exports.default;